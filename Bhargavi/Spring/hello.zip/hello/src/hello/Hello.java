package hello;

public class Hello {
private String name;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
public void display()
{
	System.out.println("hello "+name);
}

@Override
public boolean equals(Object arg0) {
	// TODO Auto-generated method stub
	return super.equals(arg0);
}

}
