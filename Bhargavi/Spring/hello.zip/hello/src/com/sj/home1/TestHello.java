package com.sj.home1;

  
import javax.annotation.Resource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
//import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.ClassPathResource;

import hello.Hello; 

public class TestHello {
	public static void main(String[] args) {  
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("hello.xml"));
	      
	    Hello student=(Hello)factory.getBean("hellobean");  
	    student.display();  
	    Hello student1=(Hello)factory.getBean("hellobean");  
	    student1.display(); 
	    if(student.equals(student1))
	    	System.out.println("true");
	    else
	    	System.out.println("false");
	   /* if(student1==student)
	    	System.out.println("true");
	    else
	    	System.out.println("false");*/
	    System.out.println(student==student1);
	}  
}
