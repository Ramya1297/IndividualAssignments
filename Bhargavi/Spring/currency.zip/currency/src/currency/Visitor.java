package currency;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
public class Visitor {
	@Value("1000")
	public double amount;
	@Autowired
	@Qualifier("eur")
	CurrencyConverter conv;
	
	public Visitor() {
		
	}

	public void convertV(double amount) {
		// TODO Auto-generated method stub
		conv.convert(amount);
	}
}
