package currency;

public class America implements CurrencyConverter{
	public void convert(double amount)
	{
		amount=amount*4;
		System.out.println("america amount is:"+amount);
	}
	
}
