package currency;

public class Europe implements CurrencyConverter{
	public void convert(double amount)
	{
		amount=amount*2;
		System.out.println("european amount is:"+amount);
	}
	
}
