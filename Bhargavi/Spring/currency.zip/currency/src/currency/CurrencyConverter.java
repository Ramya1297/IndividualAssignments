package currency;

public interface CurrencyConverter {
public void convert(double amount);
}
