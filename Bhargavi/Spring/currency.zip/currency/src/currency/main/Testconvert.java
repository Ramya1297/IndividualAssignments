package currency.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import currency.America;
import currency.Europe;
import currency.Visitor;

public class Testconvert {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
				ApplicationContext context = new ClassPathXmlApplicationContext("currency.xml");
	      
	      Visitor objC = (Visitor) context.getBean("bean3");
	      objC.convertV(3000);
	     /// System.out.println(objC.amount+"");
	}	
	}