package com.sj.init;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
public class InitializeDestroy implements InitializingBean, DisposableBean{
	    @Override
	    public void afterPropertiesSet() throws Exception
	    {
	        System.out.println("Initialization method called");
	    }
	    
	    @Override
	    public void destroy() throws Exception
	    {
	        System.out.println("Destroy method called");
	    }
	    
	    public void display()
	    {
	        System.out.println("Welcome........");
	    }
}
