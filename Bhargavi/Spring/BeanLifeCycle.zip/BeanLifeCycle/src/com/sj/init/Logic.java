package com.sj.init;


import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Logic
{
    public static void main(String args[])
    {
        // Read the Configuration file using ApplicationContext
        AbstractApplicationContext applicationContext = 
                new ClassPathXmlApplicationContext("SpringConfig.xml");

        // Get the InitializeDestroyExample class instance
        InitializeDestroy id = 
                (InitializeDestroy) applicationContext.getBean("initdest");
        // Call the display() method
        id.display();

        // Closing the context
        applicationContext.close();
    }
}