package com.sj.test1;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.sj.beans.Hello2;
import com.sj.beans.Hellobean;

public class Testhello2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("hellobean.xml"));
		Hello2 h1=(Hello2)factory.getBean("bean2");
		h1.hai();
	}

}
