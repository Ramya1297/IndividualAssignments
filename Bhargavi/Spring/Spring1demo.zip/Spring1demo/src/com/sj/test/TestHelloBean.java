/**
 * 
 */
package com.sj.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.sj.beans.Hellobean;

/**
 * @author Abridge Solutions
 *
 */
@SuppressWarnings("deprecation")
public class TestHelloBean {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
BeanFactory factory=new XmlBeanFactory(new ClassPathResource("hellobean.xml"));
Hellobean h1=(Hellobean)factory.getBean("bean1");
h1.sayhello();
	}
}
