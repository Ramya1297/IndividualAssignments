package com.sj.beans;

public class Hello2 {
String msg1;

public Hello2(String msg1) {
	super();
	this.msg1 = msg1;
}
public void hai()
{
	System.out.println("hai"+msg1);
}
}
