/**
 * 
 */
package com.sj.beans;

/**
 * @author Abridge Solutions
 *
 */
public class Hellobean {
String msg;
public void setMsg(String msg)
{
	this.msg=msg;
}
public void sayhello()
{
	System.out.println("hello"+msg);
}
}
