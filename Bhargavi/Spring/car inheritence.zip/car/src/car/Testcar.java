package car;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import car.Car;
import car.Car1;

public class Testcar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
	      
	      Car1 objA = (Car1) context.getBean("car1");
	      objA.getName();
	      objA.getColor();

	      Car objB = (Car) context.getBean("car");
	      objB.getName();
	      objB.getType();
	}

}
