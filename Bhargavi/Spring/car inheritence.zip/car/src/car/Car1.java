package car;

public class Car1 extends Car{
String name;
String color;
public void getName() {
	System.out.println("name is:"+ name);
}
public void setName(String name) {
	this.name = name;
}
public void getColor() {
	System.out.println("color is:"+ color);
}
public void setColor(String color) {
	this.color = color;
}

}
