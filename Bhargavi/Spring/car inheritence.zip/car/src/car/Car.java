package car;

public class Car {
	String name;
	String type;
	public void getName() {
		System.out.println("name is:"+ name);
	}
	public void setName(String name) {
		this.name = name;
	}
	public void getType() {
		System.out.println("type is:"+ type);
	}
	public void setType(String type) {
		this.type = type;
	}

}
