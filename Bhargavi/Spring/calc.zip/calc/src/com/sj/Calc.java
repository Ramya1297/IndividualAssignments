package com.sj;

public interface Calc {
public int add(int n1,int n2);
}
