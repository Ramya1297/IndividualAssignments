package com.sj;

public class User {
Calc cal;
int x,y;
public Calc getCal() {
	return cal;
}
public void setCal(Calc cal) {
	this.cal = cal;
}
public void addition()
{
	int sum=cal.add(x, y);
	System.out.println("sum is"+sum);
}
}
