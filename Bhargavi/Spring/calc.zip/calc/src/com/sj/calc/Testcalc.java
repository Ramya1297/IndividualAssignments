package com.sj.calc;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.sj.User;

public class Testcalc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("calc.xml"));
		User h1 = (User)factory.getBean("user1");
		h1.addition();
	}
}
