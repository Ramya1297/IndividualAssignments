package emp;

public interface Department {
	public void deptname();
}
