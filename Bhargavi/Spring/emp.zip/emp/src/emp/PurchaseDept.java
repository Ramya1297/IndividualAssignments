package emp;

public class PurchaseDept implements Department{

	public void deptname()
	{
		System.out.println("the dept is purchase");
	}
}
