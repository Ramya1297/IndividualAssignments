package emp;

public class SalesDept implements Department {
	public void deptname()
	{
		System.out.println("the dept is sales");
	}
}
