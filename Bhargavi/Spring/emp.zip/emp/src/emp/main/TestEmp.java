package emp.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;



import emp.*;

public class TestEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("emp.xml"));
		Emp h1 = (Emp)factory.getBean("empbean");
		h1.dname();
	}

}
